-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.21-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------
use spring_social;
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table spring_social.admin
CREATE TABLE IF NOT EXISTS `admin` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `email_verified` bit(1) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK6dotkott2kjsp8vw4d0m25fb7` (`email`),
  UNIQUE KEY `UKc0r9atamxvbhjjvy5j8da1kam` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table spring_social.admin: ~1 rows (approximately)
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`id`, `email`, `email_verified`, `image_url`, `name`, `password`) VALUES
	(3, 'abcd@sentifi.com', b'0', NULL, 'thanh le xuan', '$2a$10$edNi7cL.xxa1J0fB2ulRZO6nKraYaRGw1OY40WqhCiFV.8AbXwDsi');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;

-- Dumping structure for table spring_social.bank_account
CREATE TABLE IF NOT EXISTS `bank_account` (
  `account_no` varchar(100) NOT NULL,
  `influencer_id` bigint(20) NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `expired` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`account_no`),
  KEY `FK_bank_account_influencers` (`influencer_id`),
  CONSTRAINT `FK_bank_account_influencers` FOREIGN KEY (`influencer_id`) REFERENCES `influencers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table spring_social.bank_account: ~0 rows (approximately)
/*!40000 ALTER TABLE `bank_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `bank_account` ENABLE KEYS */;

-- Dumping structure for table spring_social.influencers
CREATE TABLE IF NOT EXISTS `influencers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `email_verified` bit(1) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `pid` varchar(20) DEFAULT NULL COMMENT 'CMND',
  `gender` bit(1) DEFAULT NULL,
  `provider` varchar(50) NOT NULL,
  `provider_id` varchar(50) DEFAULT NULL,
  `profile_url` varchar(255) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK6dotkott2kjsp8vw4d0m25fb7` (`email`),
  UNIQUE KEY `UKkhs4ab8vyuvm3cs83ee4m0824` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table spring_social.influencers: ~4 rows (approximately)
/*!40000 ALTER TABLE `influencers` DISABLE KEYS */;
INSERT INTO `influencers` (`id`, `email`, `email_verified`, `image_url`, `name`, `pid`, `gender`, `provider`, `provider_id`, `profile_url`, `phone_number`, `password`) VALUES
	(5, 'xuanthanh.le@sentifi.com', b'0', 'https://lh5.googleusercontent.com/-o1_ERYpY2jc/AAAAAAAAAAI/AAAAAAAAAAA/ACHi3rd_30Lbjtcs9fRSY3je3Fr8R74Oug/mo/photo.jpg', 'XuanThanh Le', NULL, NULL, 'google', '109931459684664791259', NULL, NULL, NULL),
	(6, 'theblue20187@gmail.com', b'0', 'https://platform-lookaside.fbsbx.com/platform/profilepic/?asid=2448561915156571&height=250&width=250&ext=1561190985&hash=AeTfkiB7IzX_6soD', 'Lê Xuân Thành', NULL, NULL, 'facebook', '2448561915156571', NULL, NULL, NULL),
	(7, 'abcd@sentifi.com', b'0', NULL, 'mmm', NULL, NULL, 'local', NULL, NULL, NULL, '$2a$10$tV3lA.RnK1aGG6rtQ85r/u/GHx3bbmcY5jtIKvyEYx6tI9poe1aYG'),
	(8, 'aabcd@sentifi.com', b'0', NULL, 'iloveu', NULL, NULL, 'local', NULL, NULL, NULL, '$2a$10$EsKSHLDXvrFrkgfUQVGyXuflq/xtnFlXdyMclOz1dR6560gjnYyVO'),
	(9, 'izipos06@gmail.com', b'0', 'https://lh4.googleusercontent.com/-fImKM5oxVxo/AAAAAAAAAAI/AAAAAAAAAFo/J2UHkqaAPD0/photo.jpg', 'Ph?n m?m qu?n lý bán hàng Izipos', NULL, NULL, 'google', '112601266791921580115', NULL, NULL, NULL);
/*!40000 ALTER TABLE `influencers` ENABLE KEYS */;

-- Dumping structure for table spring_social.influencers_topics
CREATE TABLE IF NOT EXISTS `influencers_topics` (
  `influencer_id` bigint(20) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `sharing_count` bigint(20) DEFAULT '0',
  PRIMARY KEY (`influencer_id`,`topic_id`),
  KEY `FK_influencers_topics_topic` (`topic_id`),
  CONSTRAINT `FK_influencers_topics_influencers` FOREIGN KEY (`influencer_id`) REFERENCES `influencers` (`id`),
  CONSTRAINT `FK_influencers_topics_topic` FOREIGN KEY (`topic_id`) REFERENCES `topic` (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table spring_social.influencers_topics: ~0 rows (approximately)
/*!40000 ALTER TABLE `influencers_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `influencers_topics` ENABLE KEYS */;

-- Dumping structure for table spring_social.occupies_influencers
CREATE TABLE IF NOT EXISTS `occupies_influencers` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `company_name` varchar(100) DEFAULT NULL,
  `responsibilities` varchar(300) DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `influencer_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_occupies_influencers_influencers` (`influencer_id`),
  CONSTRAINT `FK_occupies_influencers_influencers` FOREIGN KEY (`influencer_id`) REFERENCES `influencers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table spring_social.occupies_influencers: ~0 rows (approximately)
/*!40000 ALTER TABLE `occupies_influencers` DISABLE KEYS */;
/*!40000 ALTER TABLE `occupies_influencers` ENABLE KEYS */;

-- Dumping structure for table spring_social.topic
CREATE TABLE IF NOT EXISTS `topic` (
  `topic_id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1: active | 2: deactive',
  `name` varchar(50) NOT NULL DEFAULT '1',
  `description` varchar(200) DEFAULT '1',
  `created_at` date NOT NULL,
  PRIMARY KEY (`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table spring_social.topic: ~0 rows (approximately)
/*!40000 ALTER TABLE `topic` DISABLE KEYS */;
/*!40000 ALTER TABLE `topic` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
