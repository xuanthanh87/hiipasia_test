package thanh.le.springoauth.entity;

import javax.persistence.*;
import java.sql.Date;
import java.util.Objects;

@Entity
@Table(name = "occupies_influencers")
public class OccupiesInfluencersEntity {
    private int id;
    private String title;
    private String companyName;
    private String responsibilities;
    private Date startDate;
    private Date endDate;
    private long influencerId;
    private InfluencersEntity influencersByInfluencerId;

    @Id
    @Column(name = "id")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Basic
    @Column(name = "title")
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Basic
    @Column(name = "company_name")
    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    @Basic
    @Column(name = "responsibilities")
    public String getResponsibilities() {
        return responsibilities;
    }

    public void setResponsibilities(String responsibilities) {
        this.responsibilities = responsibilities;
    }

    @Basic
    @Column(name = "start_date")
    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    @Basic
    @Column(name = "end_date")
    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    @Basic
    @Column(name = "influencer_id",insertable = false,updatable = false)
    public long getInfluencerId() {
        return influencerId;
    }

    public void setInfluencerId(long influencerId) {
        this.influencerId = influencerId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OccupiesInfluencersEntity that = (OccupiesInfluencersEntity) o;
        return id == that.id &&
                influencerId == that.influencerId &&
                Objects.equals(title, that.title) &&
                Objects.equals(companyName, that.companyName) &&
                Objects.equals(responsibilities, that.responsibilities) &&
                Objects.equals(startDate, that.startDate) &&
                Objects.equals(endDate, that.endDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, title, companyName, responsibilities, startDate, endDate, influencerId);
    }

    @ManyToOne
    @JoinColumn(name = "influencer_id", referencedColumnName = "id", nullable = false)
    public InfluencersEntity getInfluencersByInfluencerId() {
        return influencersByInfluencerId;
    }

    public void setInfluencersByInfluencerId(InfluencersEntity influencersByInfluencerId) {
        this.influencersByInfluencerId = influencersByInfluencerId;
    }
}
