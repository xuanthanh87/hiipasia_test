package thanh.le.springoauth.dto;

public enum  AuthProvider {
    local,
    facebook,
    google
}
