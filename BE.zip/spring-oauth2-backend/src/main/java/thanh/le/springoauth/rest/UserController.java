package thanh.le.springoauth.rest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import thanh.le.springoauth.exception.ResourceNotFoundException;
import thanh.le.springoauth.entity.InfluencersEntity;
import thanh.le.springoauth.repository.InfluencerRepository;
import thanh.le.springoauth.security.CurrentUser;
import thanh.le.springoauth.security.UserPrincipal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(
        value = "profile",
        description = "REST API for admin only",
        tags = {"profile"}
)
@RestController
public class UserController {

    @Autowired
    private InfluencerRepository influencerRepository;

    @ApiOperation(
            value = "influencer profile",
            tags = {"profile"}
    )
    @GetMapping("/influencer/me")
    @PreAuthorize("hasRole('USER')")
    public InfluencersEntity getCurrentUser(@CurrentUser UserPrincipal userPrincipal) {
        return influencerRepository.findById(userPrincipal.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Admin", "id", userPrincipal.getId()));
    }
}
