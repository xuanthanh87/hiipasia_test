package thanh.le.springoauth.security;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import thanh.le.springoauth.entity.InfluencersEntity;
import thanh.le.springoauth.exception.ResourceNotFoundException;
import thanh.le.springoauth.repository.InfluencerRepository;


@Service
public class CustomUserDetailsService implements UserDetailsService {
    @Autowired
    InfluencerRepository influencerRepository;

    @Override
    @Transactional
    public UserDetails loadUserByUsername(String email)
            throws UsernameNotFoundException {
        InfluencersEntity user = influencerRepository.findByEmail(email)
                .orElseThrow(() ->
                        new UsernameNotFoundException("Admin not found with email : " + email)
        );

        return UserPrincipal.create(user);
    }

    @Transactional
    public UserDetails loadUserById(Long id) {
        //found in admin or influencer table
        InfluencersEntity user = influencerRepository.findById(id)
        .orElseThrow(
            () -> new ResourceNotFoundException("Admin", "id", id)
        );
        return UserPrincipal.create(user);
    }
}