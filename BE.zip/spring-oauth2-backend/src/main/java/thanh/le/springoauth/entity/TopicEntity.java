package thanh.le.springoauth.entity;

import javax.persistence.*;
import java.sql.Date;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "topic", schema = "spring_social", catalog = "")
public class TopicEntity {
    private int topicId;
    private byte status;
    private String name;
    private String description;
    private Date createdAt;
    private Collection<InfluencersTopicsEntity> influencersTopicsByTopicId;

    @Id
    @Column(name = "topic_id")
    public int getTopicId() {
        return topicId;
    }

    public void setTopicId(int topicId) {
        this.topicId = topicId;
    }

    @Basic
    @Column(name = "status")
    public byte getStatus() {
        return status;
    }

    public void setStatus(byte status) {
        this.status = status;
    }

    @Basic
    @Column(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "description")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "created_at")
    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TopicEntity that = (TopicEntity) o;
        return topicId == that.topicId &&
                status == that.status &&
                Objects.equals(name, that.name) &&
                Objects.equals(description, that.description) &&
                Objects.equals(createdAt, that.createdAt);
    }

    @Override
    public int hashCode() {
        return Objects.hash(topicId, status, name, description, createdAt);
    }

    @OneToMany(mappedBy = "topicByTopicId")
    public Collection<InfluencersTopicsEntity> getInfluencersTopicsByTopicId() {
        return influencersTopicsByTopicId;
    }

    public void setInfluencersTopicsByTopicId(Collection<InfluencersTopicsEntity> influencersTopicsByTopicId) {
        this.influencersTopicsByTopicId = influencersTopicsByTopicId;
    }
}
