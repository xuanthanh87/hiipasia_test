package thanh.le.springoauth.entity;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "bank_account")
public class BankAccountEntity {
    private String accountNo;
    private long influencerId;
    private String bankName;
    private Timestamp expired;
    private InfluencersEntity influencersByInfluencerId;

    @Id
    @Column(name = "account_no")
    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    @Basic
    @Column(name = "influencer_id",insertable = false,updatable = false)
    public long getInfluencerId() {
        return influencerId;
    }

    public void setInfluencerId(long influencerId) {
        this.influencerId = influencerId;
    }

    @Basic
    @Column(name = "bank_name")
    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    @Basic
    @Column(name = "expired")
    public Timestamp getExpired() {
        return expired;
    }

    public void setExpired(Timestamp expired) {
        this.expired = expired;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BankAccountEntity that = (BankAccountEntity) o;
        return influencerId == that.influencerId &&
                Objects.equals(accountNo, that.accountNo) &&
                Objects.equals(bankName, that.bankName) &&
                Objects.equals(expired, that.expired);
    }

    @Override
    public int hashCode() {
        return Objects.hash(accountNo, influencerId, bankName, expired);
    }

    @ManyToOne
    @JoinColumn(name = "influencer_id", referencedColumnName = "id", nullable = false)
    public InfluencersEntity getInfluencersByInfluencerId() {
        return influencersByInfluencerId;
    }

    public void setInfluencersByInfluencerId(InfluencersEntity influencersByInfluencerId) {
        this.influencersByInfluencerId = influencersByInfluencerId;
    }
}
