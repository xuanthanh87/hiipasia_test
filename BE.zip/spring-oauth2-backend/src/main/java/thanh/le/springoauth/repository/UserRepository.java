package thanh.le.springoauth.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import thanh.le.springoauth.entity.AdminEntity;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<AdminEntity, Long> {

    /**
     *
     * For Admin user only
     * @param email
     * @return
     */
    Optional<AdminEntity> findByEmail(String email);

    Boolean existsByEmail(String email);

}
