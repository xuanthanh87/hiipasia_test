package thanh.le.springoauth.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Objects;

public class InfluencersTopicsEntityPK implements Serializable {
    private long influencerId;
    private int topicId;

    @Column(name = "influencer_id",insertable = false,updatable = false)
    @Id
    public long getInfluencerId() {
        return influencerId;
    }

    public void setInfluencerId(long influencerId) {
        this.influencerId = influencerId;
    }

    @Column(name = "topic_id",updatable = false, insertable = false)
    @Id
    public int getTopicId() {
        return topicId;
    }

    public void setTopicId(int topicId) {
        this.topicId = topicId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InfluencersTopicsEntityPK that = (InfluencersTopicsEntityPK) o;
        return influencerId == that.influencerId &&
                topicId == that.topicId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(influencerId, topicId);
    }
}
