package thanh.le.springoauth.rest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import thanh.le.springoauth.service.InfluencerService;
import thanh.le.springoauth.entity.InfluencersEntity;
import thanh.le.springoauth.dto.InfluencerSearchRequest;

@Api(
        value = "Admin",
        description = "REST API for admin only",
        tags = {"admin"}
)
@RestController
@RequestMapping("/admin")
public class InfluencerManagementController {

    @Autowired
    private InfluencerService influencerService;


    @ApiOperation(
            value = "ping api",
            tags = {"admin"}
    )
    @GetMapping("/influencers/test")
    @PreAuthorize("hasRole('ADMIN')")
    public String test() {
        return "OK";
    }


    @ApiOperation(
            value = "influencer search api",
            tags = {"admin"}
    )
    @PostMapping("/influencers/search")
    @PreAuthorize("hasRole('ADMIN')")
    public Page<InfluencersEntity> search(
            @PageableDefault(page=0, size=10) Pageable pageable,
          @RequestBody InfluencerSearchRequest searchOperation) {
            return influencerService.search(searchOperation,pageable);
    }
}
