package thanh.le.springoauth.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;
import thanh.le.springoauth.entity.InfluencersEntity;

import java.util.Optional;

@Repository
public interface InfluencerRepository extends JpaRepository<InfluencersEntity, Long>,JpaSpecificationExecutor {

    Optional<InfluencersEntity> findByEmail(String email);

    Boolean existsByEmail(String email);

}
