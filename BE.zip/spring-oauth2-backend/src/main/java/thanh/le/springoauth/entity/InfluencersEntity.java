package thanh.le.springoauth.entity;

import thanh.le.springoauth.dto.AuthProvider;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "influencers")
public class InfluencersEntity {
    private long id;
    private String email;
    private boolean emailVerified;
    private String imageUrl;
    private String name;
    private String pid;
    private Boolean gender;


    private AuthProvider provider;
    //private String provider;
    private String providerId;
    private String profileUrl;
    private String phoneNumber;
    private String password;
    private Collection<BankAccountEntity> bankAccountsById;
    private Collection<InfluencersTopicsEntity> influencersTopicsById;
    private Collection<OccupiesInfluencersEntity> occupiesInfluencersById;

    @Id
    @Column(name = "id")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Basic
    @Column(name = "email")
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Basic
    @Column(name = "email_verified")
    public boolean isEmailVerified() {
        return emailVerified;
    }

    public void setEmailVerified(boolean emailVerified) {
        this.emailVerified = emailVerified;
    }

    @Basic
    @Column(name = "image_url")
    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    @Basic
    @Column(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "pid")
    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    @Basic
    @Column(name = "gender")
    public Boolean getGender() {
        return gender;
    }

    public void setGender(Boolean gender) {
        this.gender = gender;
    }

    @Basic
    @Column(name = "provider")
    @NotNull
    @Enumerated(EnumType.STRING)
    public AuthProvider getProvider() {
        return provider;
    }

    public void setProvider(AuthProvider provider) {
        this.provider = provider;
    }

    @Basic
    @Column(name = "provider_id")
    public String getProviderId() {
        return providerId;
    }

    public void setProviderId(String providerId) {
        this.providerId = providerId;
    }

    @Basic
    @Column(name = "profile_url")
    public String getProfileUrl() {
        return profileUrl;
    }

    public void setProfileUrl(String profileUrl) {
        this.profileUrl = profileUrl;
    }

    @Basic
    @Column(name = "phone_number")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Basic
    @Column(name = "password")
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InfluencersEntity that = (InfluencersEntity) o;
        return id == that.id &&
                emailVerified == that.emailVerified &&
                Objects.equals(email, that.email) &&
                Objects.equals(imageUrl, that.imageUrl) &&
                Objects.equals(name, that.name) &&
                Objects.equals(pid, that.pid) &&
                Objects.equals(gender, that.gender) &&
                Objects.equals(provider, that.provider) &&
                Objects.equals(providerId, that.providerId) &&
                Objects.equals(profileUrl, that.profileUrl) &&
                Objects.equals(phoneNumber, that.phoneNumber) &&
                Objects.equals(password, that.password);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, email, emailVerified, imageUrl, name, pid, gender, provider, providerId, profileUrl, phoneNumber, password);
    }

    @OneToMany(mappedBy = "influencersByInfluencerId")
    public Collection<BankAccountEntity> getBankAccountsById() {
        return bankAccountsById;
    }

    public void setBankAccountsById(Collection<BankAccountEntity> bankAccountsById) {
        this.bankAccountsById = bankAccountsById;
    }

    @OneToMany(mappedBy = "influencersByInfluencerId")
    public Collection<InfluencersTopicsEntity> getInfluencersTopicsById() {
        return influencersTopicsById;
    }

    public void setInfluencersTopicsById(Collection<InfluencersTopicsEntity> influencersTopicsById) {
        this.influencersTopicsById = influencersTopicsById;
    }

    @OneToMany(mappedBy = "influencersByInfluencerId")
    public Collection<OccupiesInfluencersEntity> getOccupiesInfluencersById() {
        return occupiesInfluencersById;
    }

    public void setOccupiesInfluencersById(Collection<OccupiesInfluencersEntity> occupiesInfluencersById) {
        this.occupiesInfluencersById = occupiesInfluencersById;
    }
}
