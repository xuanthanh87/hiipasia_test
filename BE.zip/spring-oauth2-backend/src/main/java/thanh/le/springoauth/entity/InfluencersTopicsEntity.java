package thanh.le.springoauth.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "influencers_topics")
@IdClass(InfluencersTopicsEntityPK.class)
public class InfluencersTopicsEntity {
    private long influencerId;
    private int topicId;
    private Long sharingCount;
    private InfluencersEntity influencersByInfluencerId;
    private TopicEntity topicByTopicId;

    @Id
    @Column(name = "influencer_id",insertable = false,updatable = false)
    public long getInfluencerId() {
        return influencerId;
    }

    public void setInfluencerId(long influencerId) {
        this.influencerId = influencerId;
    }

    @Id
    @Column(name = "topic_id",insertable = false,updatable = false)
    public int getTopicId() {
        return topicId;
    }

    public void setTopicId(int topicId) {
        this.topicId = topicId;
    }

    @Basic
    @Column(name = "sharing_count")
    public Long getSharingCount() {
        return sharingCount;
    }

    public void setSharingCount(Long sharingCount) {
        this.sharingCount = sharingCount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        InfluencersTopicsEntity that = (InfluencersTopicsEntity) o;
        return influencerId == that.influencerId &&
                topicId == that.topicId &&
                Objects.equals(sharingCount, that.sharingCount);
    }

    @Override
    public int hashCode() {
        return Objects.hash(influencerId, topicId, sharingCount);
    }

    @ManyToOne
    @JoinColumn(name = "influencer_id", referencedColumnName = "id", nullable = false)
    public InfluencersEntity getInfluencersByInfluencerId() {
        return influencersByInfluencerId;
    }

    public void setInfluencersByInfluencerId(InfluencersEntity influencersByInfluencerId) {
        this.influencersByInfluencerId = influencersByInfluencerId;
    }

    @ManyToOne
    @JoinColumn(name = "topic_id", referencedColumnName = "topic_id", nullable = false)
    public TopicEntity getTopicByTopicId() {
        return topicByTopicId;
    }

    public void setTopicByTopicId(TopicEntity topicByTopicId) {
        this.topicByTopicId = topicByTopicId;
    }
}
