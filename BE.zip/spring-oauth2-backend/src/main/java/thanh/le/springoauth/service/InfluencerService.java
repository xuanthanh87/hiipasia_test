package thanh.le.springoauth.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import thanh.le.springoauth.entity.InfluencersEntity;
import thanh.le.springoauth.dto.InfluencerSearchRequest;
import thanh.le.springoauth.repository.InfluencerRepository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Service
public class InfluencerService {

    @Autowired
    private InfluencerRepository influencerRepository;

  /*  public Page<Influencer> search(Pageable pageable, InfluencerSearchRequest request){
      return   influencerRepository.search(request.getName(),request.getEmail(),request.getPhoneNumber(),request.getProvider(),pageable);
    }*/

    public Page<InfluencersEntity> search(InfluencerSearchRequest filter,Pageable pageable) {

        Page<InfluencersEntity> employees = influencerRepository.findAll(new Specification<InfluencersEntity>() {

            @Override
            public Predicate toPredicate(Root<InfluencersEntity> root, CriteriaQuery< ?> query, CriteriaBuilder cb) {

                List<Predicate> predicates = new ArrayList<>();

                // If designation is specified in filter, add equal where clause
                if (filter.getEmail() != null) {
                    predicates.add(cb.equal(root.get("email"), filter.getEmail()));
                }

                // If firstName is specified in filter, add contains (lile)
                // filter to where clause with ignore case
                if (filter.getName() != null) {
                    predicates.add(cb.like(cb.lower(root.get("name")),
                            "%" + filter.getName().toLowerCase() + "%"));
                }

                // If lastName is specified in filter, add contains (lile)
                // filter to where clause with ignore case
                if (filter.getPhoneNumber() != null) {
                    predicates.add(cb.like(cb.lower(root.get("phoneNumber")),
                            "%" + filter.getPhoneNumber().toLowerCase() + "%"));
                }

                if (filter.getProvider() != null) {
                    predicates.add(cb.equal(root.get("provider"), filter.getProvider()));
                }

                return cb.and(predicates.toArray(new Predicate[0]));
            }
        },pageable);

        return employees;
    }

}
