package thanh.le.springoauth.dto;

import lombok.Data;

@Data
public class InfluencerSearchRequest {
    private String name;
    private String email;
    private String phoneNumber;
    private String provider;



}
