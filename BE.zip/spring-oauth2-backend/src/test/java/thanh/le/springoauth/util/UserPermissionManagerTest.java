package thanh.le.springoauth.util;

import com.google.common.collect.ImmutableList;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.util.*;

import static org.hamcrest.core.Is.is;

@RunWith(value = Parameterized.class)
public class UserPermissionManagerTest {

    @Parameterized.Parameter(0)
    public String [] input;

    @Parameterized.Parameter(1)
    public int nWord;

    @Parameterized.Parameter(2)
    public List<String> expected;



    @Parameterized.Parameters(name = "{index} - {0}")
    public static Collection<Object[]> data() {
        return Arrays.asList(
                new Object[][] {
                        {
                                new String []{
                                        "he","loves","his","lovely","cat","that","loves","he","very","much"
                                },
                                10,
                                ImmutableList.of("[cat,his,lovely,much,that,very:1]",
                                        "[he,loves:2]"
                                        )
                        },

                        {
                                new String []{
                                        "aa","bb","c","e","f","aa","aa","bb","g","m"
                                },
                                10,
                                ImmutableList.of("[c,e,f,g,m:1]", "[bb:2]", "[aa:3]"
                                )
                        },


                });
    }

    @Test
    public void given_PermsionsAndManger_when_buildDate_then_shouldReturnPermissionForEachUser() {

        //WHEN
        List<String> result = StringHelper.mostUsedWords(input,nWord);
        //THEN
        Assert.assertThat(result,is(expected));

    }
}
